import math

def main():
    # Nhập bán kính từ người dùng
    r = float(input("Nhập bán kính r: "))

    # Tính chu vi và diện tích
    cv = 2 * math.pi * r
    dt = math.pi * (r ** 2)

    # In kết quả
    print(f"Chu vi hình tròn = {cv:.2f}")
    print(f"Diện tích hình tròn = {dt:.2f}")

if __name__ == "__main__":
    main()
